# RAM PLAYER v19.0 — AMOLED 3D Edition (Build 190)

## What Changed in v19.0
- **Complete Branding Upgrade**: Rebranded user-facing UI, launcher icon, TV banner, splash screen, top bar, sidebar, quick menu, settings center, and About screen to **RAM PLAYER v19.0** (`versionCode = 190`, `versionName = "19.0"`, package `com.harindra.iptvpro` preserved for seamless in-place updates).
- **True AMOLED 3D Design System**: Pure AMOLED black (`#000000`), dark charcoal (`#0B0F19`), brushed titanium (`#CBD5E1`), electric cyan (`#38BDF8`), and violet (`#8B5CF6`) across glassmorphism modals, top bar, sidebar, and OSD.
- **Custom 3D Artwork**: Added `branding/ram_player_icon_1024.jpg` (1:1 3D metallic icon) and `branding/ram_player_promo_16x9.jpg` (16:9 promotional artwork).
- **New Playback & Remote Features**:
  - **Configurable OSD Auto-Hide Timeout** (`2s / 3s / 5s / 8s / 12s`) persisted in `ProfileStore`.
  - **Player Lock (Accidental Button Protection)** toggleable from Quick Menu & Playback Settings, blocking accidental zap/back keys until unlocked via OK/Menu.
  - **Optional External Player Fallback** (`Intent.ACTION_VIEW` video/stream launcher) in Quick Menu & Playback Settings.
  - **Sleep Timer** (`15m / 30m / 45m / 60m / 90m / Custom / OFF`).
  - **English + Hindi Localization** (`values/strings.xml` + `values-hi/strings.xml`).
  - **Legal Disclaimer** in `About & Update Center` and `strings.xml`.
- **100% Feature & Data Preservation**: All 106 original files, AES-256 profile encryption, `LiveTvBackgroundPlaybackController`, `FIRST_BATCH_SIZE = 40`, and 512MB low-RAM optimizations preserved intact.
