package com.harindra.iptvpro

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InterruptedIOException
import java.net.SocketTimeoutException
import java.net.URI
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * StreamX Media3 Pro v18.0 Next-Generation Ultra Extreme Edition — Adaptive Preload Controller,
 * Real Balanced Media Preloader & Zapping Benchmark Telemetry for 512MB RAM Android Smart TVs.
 */
@OptIn(UnstableApi::class)
object StreamPreFetcher {
    private const val MIN_FREE_HEAP_FOR_PREFETCH = 16L * 1024L * 1024L // 16 MB safety floor for 512MB TVs
    const val MAX_MANIFEST_BYTES = 64 * 1024 // 64 KB cap per .m3u8 manifest
    const val MAX_INITIAL_SEGMENT_BYTES = 96 * 1024 // 96 KB bounded initial segment prefix in RAM
    const val MAX_TOTAL_RAM_CACHE_BYTES = 320 * 1024 // 320 KB strict total RAM cap
    const val MANIFEST_CACHE_TTL_MS = 7_500L // 7.5s live manifest/segment freshness window
    const val PREPARED_SOURCE_TTL_MS = 7_500L // Matches manifest freshness so stale sources are never reused
    private const val SOCKET_WARM_TTL_MS = 25_000L
    private const val NEGATIVE_COOLDOWN_MS = 15_000L // 15s cooldown for 401/403/404/429 preload failures
    private const val PRELOAD_TIMEOUT_MS = 1800L

    enum class StreamFormat {
        HLS, DASH, RTSP, MPEG_TS, OTHER
    }

    enum class PreloadState {
        IDLE,
        PRELOADING,
        READY,
        HANDED_OFF,
        CANCELLED,
        AUTH_ERROR,
        NOT_FOUND,
        RATE_LIMITED,
        SERVER_ERROR,
        TIMEOUT,
        NETWORK_ERROR,
        INVALID_CONTENT,
        SKIPPED_LOW_MEM,
        SKIPPED_OFFLINE,
        SKIPPED_UNSUPPORTED
    }

    data class HlsPreloadPlan(
        val isMasterPlaylist: Boolean,
        val variantPlaylistUrl: String?,
        val initSegmentUrl: String?,
        val firstMediaSegmentUrl: String?
    )

    data class CachedPreloadResource(
        val url: String,
        val ownerStreamUrl: String,
        val data: ByteArray,
        val contentType: String?,
        val timestampMs: Long,
        val isComplete: Boolean,
        val totalResourceLength: Long = C.LENGTH_UNSET.toLong()
    )

    private data class FetchResult(
        val finalUrl: String,
        val statusCode: Int,
        val data: ByteArray,
        val contentType: String?,
        val isComplete: Boolean,
        val totalResourceLength: Long,
        val failureState: PreloadState? = null
    )

    private data class PreparedChannelEntry(
        val streamUrl: String,
        val generationId: Long,
        val format: StreamFormat,
        val mediaItem: MediaItem,
        val mediaSource: MediaSource?,
        val createdAtMs: Long,
        val preloadedBytes: Int
    )

    private val prefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val preloadMutex = Mutex()
    private val stateLock = Any()

    private var adjacentJob: Job? = null
    private var focusJob: Job? = null
    private val generationCounter = AtomicLong(0L)

    @Volatile
    private var activeNetworkCall: Call? = null

    @Volatile
    private var currentPlayingUrl: String = ""

    @Volatile
    private var nextCandidateUrl: String = ""

    @Volatile
    private var prevCandidateUrl: String = ""

    @Volatile
    private var dpadFocusTargetUrl: String = ""

    @Volatile
    private var lastSwitchingForward: Boolean = true

    @Volatile
    private var networkAvailable: Boolean = true

    @Volatile
    private var slowNetworkDegraded: Boolean = false

    @Volatile
    private var currentState: PreloadState = PreloadState.IDLE

    @Volatile
    private var currentTargetFormat: StreamFormat = StreamFormat.OTHER

    @Volatile
    private var preparedEntry: PreparedChannelEntry? = null

    @Volatile
    private var activePerformanceMode: PerformanceMode = PerformanceMode.SMART_BALANCED

    @Volatile
    private var lastRemoteFocusTimestampMs: Long = 0L

    @Volatile
    private var lastRemoteNavigationIntervalMs: Long = 500L

    private val preloadAttemptCount = AtomicInteger(0)
    private val preloadReadyCount = AtomicInteger(0)
    private val preloadHitCount = AtomicInteger(0)
    private val preloadMissCount = AtomicInteger(0)
    private val preloadFailCount = AtomicInteger(0)

    fun setPerformanceMode(mode: PerformanceMode) {
        activePerformanceMode = mode
        if (mode == PerformanceMode.LOW_MEMORY) {
            trimIdleCacheOnLowMemory()
        }
    }

    fun getPerformanceMode(): PerformanceMode = activePerformanceMode

    fun prefetchHitRatePercent(): Int {
        val hits = preloadHitCount.get()
        val totalLookups = hits + preloadMissCount.get()
        if (totalLookups <= 0) return 0
        return ((hits * 100) / totalLookups).coerceIn(0, 100)
    }

    fun failedPrefetchRatePercent(): Int {
        val attempts = preloadAttemptCount.get()
        if (attempts <= 0) return 0
        return ((preloadFailCount.get() * 100) / attempts).coerceIn(0, 100)
    }

    private class BoundedByteCache(private val maxBytes: Int) {
        private val map = LinkedHashMap<String, CachedPreloadResource>(16, 0.75f, true)
        private var currentBytes: Int = 0

        fun get(key: String): CachedPreloadResource? = map[key]

        fun put(key: String, value: CachedPreloadResource) {
            val prev = map.put(key, value)
            if (prev != null) currentBytes -= prev.data.size.coerceAtLeast(1)
            currentBytes += value.data.size.coerceAtLeast(1)
            val iter = map.entries.iterator()
            while (currentBytes > maxBytes && iter.hasNext()) {
                val eldest = iter.next()
                currentBytes -= eldest.value.data.size.coerceAtLeast(1)
                iter.remove()
            }
            if (currentBytes < 0) currentBytes = 0
        }

        fun remove(key: String): CachedPreloadResource? {
            val removed = map.remove(key)
            if (removed != null) {
                currentBytes = (currentBytes - removed.data.size.coerceAtLeast(1)).coerceAtLeast(0)
            }
            return removed
        }

        fun snapshot(): Map<String, CachedPreloadResource> = LinkedHashMap(map)

        fun evictAll() {
            map.clear()
            currentBytes = 0
        }

        fun size(): Int = currentBytes
    }

    private class BoundedEntryMap<V>(private val maxEntries: Int) {
        private val map = object : LinkedHashMap<String, V>(maxEntries, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, V>?): Boolean {
                return size > maxEntries
            }
        }
        fun get(key: String): V? = map[key]
        fun put(key: String, value: V) { map[key] = value }
        fun evictAll() { map.clear() }
        fun size(): Int = map.size
    }

    // Bounded in-memory LRU for preloaded manifests and initial segment ranges (strictly capped at 320 KB)
    private val ramPreloadCache = BoundedByteCache(MAX_TOTAL_RAM_CACHE_BYTES)

    // Lightweight in-memory LRU tracking recently warmed stream hosts/URLs (<16 KB RAM total)
    private val warmedSocketTimestamps = BoundedEntryMap<Long>(64)

    // Short-lived negative cooldown cache for URLs that returned 401/403/404/429 during preloading
    private val failedUrlCooldownMap = BoundedEntryMap<Pair<Long, PreloadState>>(64)

    fun detectStreamFormat(url: String?): StreamFormat {
        if (url.isNullOrBlank()) return StreamFormat.OTHER
        val cleanUrl = url.substringBefore('|').trim()
        val pathPart = cleanUrl.substringBefore('?').substringBefore('#').lowercase(Locale.ROOT)
        return when {
            pathPart.endsWith(".m3u8") || cleanUrl.contains(".m3u8", ignoreCase = true) || cleanUrl.contains("output=m3u8", ignoreCase = true) -> StreamFormat.HLS
            pathPart.endsWith(".mpd") || cleanUrl.contains(".mpd", ignoreCase = true) -> StreamFormat.DASH
            cleanUrl.startsWith("rtsp://", ignoreCase = true) -> StreamFormat.RTSP
            pathPart.endsWith(".ts") || cleanUrl.contains("/live/", ignoreCase = true) -> StreamFormat.MPEG_TS
            else -> StreamFormat.OTHER
        }
    }

    fun resolveRelativeUrl(baseUrl: String, relativeOrAbsolute: String): String {
        val trimmed = relativeOrAbsolute.trim()
        if (trimmed.isEmpty()) return ""
        val baseQuery = baseUrl.substringAfter('?', "").substringBefore('#')
        val isRelative = !trimmed.startsWith("http://", ignoreCase = true) &&
            !trimmed.startsWith("https://", ignoreCase = true) &&
            !trimmed.startsWith("rtsp://", ignoreCase = true)

        val resolvedBase = if (!isRelative) {
            trimmed
        } else {
            try {
                val resolved = baseUrl.toHttpUrlOrNull()?.resolve(trimmed)?.toString()
                if (!resolved.isNullOrBlank()) {
                    resolved
                } else {
                    URI.create(baseUrl).resolve(trimmed).toString()
                }
            } catch (_: Exception) {
                val baseNoQuery = baseUrl.substringBefore('?')
                val slashIdx = baseNoQuery.lastIndexOf('/')
                if (slashIdx > 7) {
                    "${baseNoQuery.substring(0, slashIdx + 1)}${trimmed.removePrefix("/")}"
                } else {
                    trimmed
                }
            }
        }

        if (isRelative && baseQuery.isNotEmpty() && !resolvedBase.contains('?')) {
            return "$resolvedBase?$baseQuery"
        }
        return resolvedBase
    }

    fun classifyHttpStatus(statusCode: Int): PreloadState? {
        return when (statusCode) {
            200, 206 -> null
            401, 403 -> PreloadState.AUTH_ERROR
            404, 410 -> PreloadState.NOT_FOUND
            429 -> PreloadState.RATE_LIMITED
            in 500..599 -> PreloadState.SERVER_ERROR
            else -> PreloadState.NETWORK_ERROR
        }
    }

    fun classifyException(e: Throwable): PreloadState {
        return when (e) {
            is SocketTimeoutException -> PreloadState.TIMEOUT
            is InterruptedIOException -> if (e.message?.contains("timeout", ignoreCase = true) == true) {
                PreloadState.TIMEOUT
            } else {
                PreloadState.CANCELLED
            }
            is IOException -> if (e.message?.contains("Canceled", ignoreCase = true) == true) {
                PreloadState.CANCELLED
            } else {
                PreloadState.NETWORK_ERROR
            }
            else -> PreloadState.NETWORK_ERROR
        }
    }

    fun isValidMediaSegmentBytes(bytes: ByteArray, contentType: String? = null): Boolean {
        if (bytes.size < 4) return false
        val ct = contentType?.lowercase(Locale.ROOT).orEmpty()
        if (ct.contains("text/html") || ct.contains("application/json") || ct.contains("text/xml")) {
            return false
        }
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        val b2 = bytes[2].toInt() and 0xFF
        val b3 = bytes[3].toInt() and 0xFF
        if ((b0 == '<'.code && (b1 == '!'.code || b1 == 'h'.code || b1 == 'H'.code || b1 == '?'.code)) ||
            (b0 == 0x7B && b1 == 0x22)
        ) {
            return false
        }
        if (b0 == 0x47) {
            return bytes.size < 189 || (bytes[188].toInt() and 0xFF) == 0x47
        }
        if (b0 == 'I'.code && b1 == 'D'.code && b2 == '3'.code) return true
        if (b0 == 0xFF && (b1 and 0xF0) == 0xF0) return true
        if (b0 == 'W'.code && b1 == 'E'.code && b2 == 'B'.code && b3 == 'V'.code) return true
        if (bytes.size >= 8) {
            val boxType = String(bytes, 4, 4, Charsets.US_ASCII)
            if (boxType in setOf("ftyp", "styp", "moof", "sidx", "emsg", "free", "mdat", "moov")) {
                return true
            }
        }
        return false
    }

    private fun extractLongAttrFast(line: String, key: String, defaultVal: Long): Long {
        val idx = line.indexOf(key, ignoreCase = true)
        if (idx < 0) return defaultVal
        var i = idx + key.length
        var acc = 0L
        var digits = 0
        while (i < line.length && line[i] in '0'..'9') {
            acc = acc * 10L + (line[i] - '0')
            digits++
            i++
        }
        return if (digits > 0) acc else defaultVal
    }

    private fun extractResolutionHeightFast(line: String, defaultHeight: Int): Int {
        val idx = line.indexOf("RESOLUTION=", ignoreCase = true)
        if (idx < 0) return defaultHeight
        var i = idx + "RESOLUTION=".length
        while (i < line.length && line[i] in '0'..'9') i++
        if (i >= line.length || (line[i] != 'x' && line[i] != 'X')) return defaultHeight
        i++
        var h = 0
        var digits = 0
        while (i < line.length && line[i] in '0'..'9') {
            h = h * 10 + (line[i] - '0')
            digits++
            i++
        }
        return if (digits > 0) h else defaultHeight
    }

    private fun extractQuotedUriAttrFast(line: String): String {
        val idx = line.indexOf("URI=\"", ignoreCase = true)
        if (idx < 0) return ""
        val start = idx + 5
        val end = line.indexOf('"', startIndex = start)
        return if (end > start) line.substring(start, end).trim() else ""
    }

    fun parseHlsPlaylistTargets(playlistUrl: String, content: String): HlsPreloadPlan {
        val lines = content.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }
        if (isMaster) {
            var bestVariantUrl: String? = null
            var bestScore = -1L
            var i = 0
            while (i < lines.size) {
                val line = lines[i]
                if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                    val bw = extractLongAttrFast(line, "BANDWIDTH=", 2_500_000L)
                    val height = extractResolutionHeightFast(line, 720)
                    var j = i + 1
                    while (j < lines.size && lines[j].startsWith("#")) j++
                    if (j < lines.size) {
                        val candidateUrl = resolveRelativeUrl(playlistUrl, lines[j])
                        val withinGuard = height <= 1080 && bw <= 8_500_000L
                        val score = if (withinGuard) bw + 10_000_000L else (10_000_000L - bw.coerceAtMost(9_999_999L))
                        if (score > bestScore && candidateUrl.isNotBlank()) {
                            bestScore = score
                            bestVariantUrl = candidateUrl
                        }
                        i = j
                    }
                }
                i++
            }
            return HlsPreloadPlan(
                isMasterPlaylist = true,
                variantPlaylistUrl = bestVariantUrl,
                initSegmentUrl = null,
                firstMediaSegmentUrl = null
            )
        }

        var initSegUrl: String? = null
        val mediaSegments = ArrayList<String>(16)
        for (line in lines) {
            if (line.startsWith("#EXT-X-MAP:", ignoreCase = true)) {
                val rawMapUri = extractQuotedUriAttrFast(line)
                if (rawMapUri.isNotBlank()) {
                    initSegUrl = resolveRelativeUrl(playlistUrl, rawMapUri)
                }
            } else if (!line.startsWith("#")) {
                val resolvedSeg = resolveRelativeUrl(playlistUrl, line)
                if (resolvedSeg.isNotBlank()) {
                    mediaSegments.add(resolvedSeg)
                }
            }
        }
        val liveEdgeSeg = when {
            mediaSegments.size >= 2 -> mediaSegments[mediaSegments.size - 2]
            mediaSegments.isNotEmpty() -> mediaSegments.last()
            else -> null
        }
        return HlsPreloadPlan(
            isMasterPlaylist = false,
            variantPlaylistUrl = null,
            initSegmentUrl = initSegUrl,
            firstMediaSegmentUrl = liveEdgeSeg
        )
    }

    private fun hasSafeHeapForPrefetch(): Boolean {
        val rt = Runtime.getRuntime()
        val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
        return freeAndUnallocated >= MIN_FREE_HEAP_FOR_PREFETCH
    }

    fun updateNetworkState(connected: Boolean, degraded: Boolean = false) {
        networkAvailable = connected
        slowNetworkDegraded = degraded
        if (!connected) {
            cancelAllPrefetches()
            synchronized(stateLock) {
                currentState = PreloadState.SKIPPED_OFFLINE
            }
        }
    }

    fun notifyChannelSwitched(activeUrl: String, forwardDirection: Boolean) {
        val cleanActive = NetworkClient.extractCleanUrlAndRegisterHeaders(activeUrl)
        synchronized(stateLock) {
            currentPlayingUrl = cleanActive
            lastSwitchingForward = forwardDirection
            generationCounter.incrementAndGet()
            cancelActiveNetworkCall()
        }
        adjacentJob?.cancel()
        focusJob?.cancel()
        evictEntriesExceptOwner(cleanActive)
    }

    fun scheduleAdjacentPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        nextUrl: String?,
        prevUrl: String?,
        preferForward: Boolean = true,
        hlsFactory: HlsMediaSource.Factory? = null,
        defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    ) {
        adjacentJob?.cancel()
        cancelActiveNetworkCall()
        lastSwitchingForward = preferForward
        nextCandidateUrl = nextUrl.orEmpty()
        prevCandidateUrl = prevUrl.orEmpty()

        val mode = activePerformanceMode
        val rawPrimary = (if (preferForward) nextUrl else prevUrl)?.trim().orEmpty()
        val rawSecondary = (if (preferForward) prevUrl else nextUrl)?.trim().orEmpty()
        val primaryTarget = NetworkClient.extractCleanUrlAndRegisterHeaders(rawPrimary)
        val secondaryDnsOnly = NetworkClient.extractCleanUrlAndRegisterHeaders(rawSecondary)
        if (primaryTarget.isEmpty() || primaryTarget == currentPlayingUrl) return

        val genId = generationCounter.incrementAndGet()
        adjacentJob = prefetchScope.launch {
            NetworkClient.prewarmHostDns(primaryTarget)
            if (secondaryDnsOnly.isNotEmpty()) {
                NetworkClient.prewarmHostDns(secondaryDnsOnly)
            }
            if (!mode.allowAdjacentSegmentPreload && mode == PerformanceMode.LOW_MEMORY) {
                return@launch
            }
            delay(mode.adjacentDelayMs)
            if (!isActive || genId != generationCounter.get()) return@launch
            preloadMutex.withLock {
                if (!isActive || genId != generationCounter.get()) return@withLock
                executeSingleTargetPreload(
                    targetUrl = primaryTarget,
                    genId = genId,
                    hlsFactory = hlsFactory,
                    defaultMediaSourceFactory = defaultMediaSourceFactory
                )
            }
        }
    }

    fun scheduleFocusPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        focusedUrl: String?,
        hlsFactory: HlsMediaSource.Factory? = null,
        defaultMediaSourceFactory: DefaultMediaSourceFactory? = null
    ) {
        focusJob?.cancel()
        val rawTarget = focusedUrl?.trim().orEmpty()
        val target = NetworkClient.extractCleanUrlAndRegisterHeaders(rawTarget)
        if (target.isEmpty() || target == currentPlayingUrl) return
        dpadFocusTargetUrl = target
        cancelActiveNetworkCall()

        val nowElapsed = SystemClock.elapsedRealtime()
        if (lastRemoteFocusTimestampMs > 0L) {
            lastRemoteNavigationIntervalMs = (nowElapsed - lastRemoteFocusTimestampMs).coerceIn(20L, 2000L)
        }
        lastRemoteFocusTimestampMs = nowElapsed

        // Adaptive debounce: if the user is holding down D-Pad fast (<95ms/step), wait slightly longer
        // before opening HTTP connections so rapid scrolling never floods sockets.
        val baseDebounce = activePerformanceMode.focusDebounceMs
        val adaptiveDebounce = if (lastRemoteNavigationIntervalMs < 95L) {
            (baseDebounce + 45L).coerceAtMost(130L)
        } else {
            baseDebounce
        }

        val genId = generationCounter.incrementAndGet()
        focusJob = prefetchScope.launch {
            NetworkClient.prewarmHostDns(target)
            delay(adaptiveDebounce)
            if (!isActive || genId != generationCounter.get()) return@launch
            preloadMutex.withLock {
                if (!isActive || genId != generationCounter.get()) return@withLock
                executeSingleTargetPreload(
                    targetUrl = target,
                    genId = genId,
                    hlsFactory = hlsFactory,
                    defaultMediaSourceFactory = defaultMediaSourceFactory
                )
            }
        }
    }

    private fun executeSingleTargetPreload(
        targetUrl: String,
        genId: Long,
        hlsFactory: HlsMediaSource.Factory?,
        defaultMediaSourceFactory: DefaultMediaSourceFactory?
    ) {
        if (genId != generationCounter.get()) return

        if (!networkAvailable) {
            transitionStateIfCurrent(genId, PreloadState.SKIPPED_OFFLINE)
            return
        }
        if (!hasSafeHeapForPrefetch()) {
            trimIdleCacheOnLowMemory()
            transitionStateIfCurrent(genId, PreloadState.SKIPPED_LOW_MEM)
            return
        }

        val now = System.currentTimeMillis()
        val cooldown = synchronized(failedUrlCooldownMap) { failedUrlCooldownMap.get(targetUrl) }
        if (cooldown != null && (now - cooldown.first) < NEGATIVE_COOLDOWN_MS) {
            transitionStateIfCurrent(genId, cooldown.second)
            return
        }

        synchronized(stateLock) {
            val existing = preparedEntry
            if (existing != null &&
                existing.streamUrl == targetUrl &&
                existing.preloadedBytes > 0 &&
                (now - existing.createdAtMs) < MANIFEST_CACHE_TTL_MS
            ) {
                if (genId == generationCounter.get()) {
                    currentState = PreloadState.READY
                }
                return
            }
        }

        val format = detectStreamFormat(targetUrl)
        synchronized(stateLock) {
            if (genId == generationCounter.get()) {
                currentTargetFormat = format
            }
        }

        if (!targetUrl.startsWith("http://", true) && !targetUrl.startsWith("https://", true)) {
            transitionStateIfCurrent(genId, PreloadState.SKIPPED_UNSUPPORTED)
            return
        }

        evictEntriesExceptOwner(targetUrl)

        preloadAttemptCount.incrementAndGet()
        transitionStateIfCurrent(genId, PreloadState.PRELOADING)

        try {
            val outcomePair: Pair<Int, PreloadState?> = when (format) {
                StreamFormat.HLS -> preloadHlsStream(targetUrl, genId)
                StreamFormat.DASH, StreamFormat.MPEG_TS, StreamFormat.OTHER -> warmLiveSocketBounded(targetUrl, genId, maxBytes = 512)
                StreamFormat.RTSP -> 0 to PreloadState.SKIPPED_UNSUPPORTED
            }

            val totalPreloadedBytes = outcomePair.first
            val failureState = outcomePair.second

            synchronized(stateLock) {
                if (genId != generationCounter.get()) {
                    currentState = PreloadState.CANCELLED
                    return
                }
                if (failureState != null || totalPreloadedBytes <= 0) {
                    preparedEntry = null
                    val finalFail = failureState ?: PreloadState.NETWORK_ERROR
                    currentState = finalFail
                    preloadFailCount.incrementAndGet()
                    if (finalFail in setOf(PreloadState.AUTH_ERROR, PreloadState.NOT_FOUND, PreloadState.RATE_LIMITED)) {
                        synchronized(failedUrlCooldownMap) {
                            failedUrlCooldownMap.put(targetUrl, System.currentTimeMillis() to finalFail)
                        }
                    }
                    return
                }

                val mediaItem = buildLiveMediaItem(targetUrl)
                val preparedSource: MediaSource? = runCatching {
                    when {
                        format == StreamFormat.HLS && hlsFactory != null -> hlsFactory.createMediaSource(mediaItem)
                        defaultMediaSourceFactory != null -> defaultMediaSourceFactory.createMediaSource(mediaItem)
                        else -> null
                    }
                }.getOrNull()

                preparedEntry = PreparedChannelEntry(
                    streamUrl = targetUrl,
                    generationId = genId,
                    format = format,
                    mediaItem = mediaItem,
                    mediaSource = preparedSource,
                    createdAtMs = System.currentTimeMillis(),
                    preloadedBytes = totalPreloadedBytes
                )
                synchronized(warmedSocketTimestamps) {
                    warmedSocketTimestamps.put(targetUrl, System.currentTimeMillis())
                }
                currentState = PreloadState.READY
                preloadReadyCount.incrementAndGet()
            }
        } catch (e: Exception) {
            val classified = classifyException(e)
            synchronized(stateLock) {
                if (genId == generationCounter.get()) {
                    preparedEntry = null
                    currentState = classified
                    if (classified != PreloadState.CANCELLED) {
                        preloadFailCount.incrementAndGet()
                    }
                } else {
                    currentState = PreloadState.CANCELLED
                }
            }
            Log.d("StreamX", "Preload stopped (${classified.name}) for ${NetworkClient.redactSensitiveUrl(targetUrl)}")
        } finally {
            activeNetworkCall = null
        }
    }

    private fun preloadHlsStream(streamUrl: String, genId: Long): Pair<Int, PreloadState?> {
        var bytesLoaded = 0
        val masterFetch = fetchBoundedBytes(
            url = streamUrl,
            maxBytes = MAX_MANIFEST_BYTES,
            rangeHeader = null
        )
        if (masterFetch.failureState != null) {
            return 0 to masterFetch.failureState
        }
        val manifestBytes = masterFetch.data
        if (manifestBytes.isEmpty()) {
            return 0 to PreloadState.INVALID_CONTENT
        }
        if (genId != generationCounter.get()) {
            return 0 to PreloadState.CANCELLED
        }

        val textSample = String(manifestBytes, Charsets.UTF_8)
        if (!textSample.contains("#EXTM3U", ignoreCase = true)) {
            if (isValidMediaSegmentBytes(manifestBytes, masterFetch.contentType)) {
                if (masterFetch.isComplete || masterFetch.statusCode == 206) {
                    putRamCacheIfCurrentGen(
                        genId = genId,
                        url = streamUrl,
                        ownerUrl = streamUrl,
                        data = manifestBytes,
                        contentType = masterFetch.contentType,
                        isComplete = masterFetch.isComplete,
                        totalLength = masterFetch.totalResourceLength
                    )
                }
                return manifestBytes.size to null
            }
            return 0 to PreloadState.INVALID_CONTENT
        }

        bytesLoaded += manifestBytes.size
        val finalPlaylistUrl = masterFetch.finalUrl
        putRamCacheIfCurrentGen(
            genId = genId,
            url = streamUrl,
            ownerUrl = streamUrl,
            data = manifestBytes,
            contentType = masterFetch.contentType,
            isComplete = true,
            totalLength = manifestBytes.size.toLong()
        )
        if (finalPlaylistUrl != streamUrl) {
            putRamCacheIfCurrentGen(
                genId = genId,
                url = finalPlaylistUrl,
                ownerUrl = streamUrl,
                data = manifestBytes,
                contentType = masterFetch.contentType,
                isComplete = true,
                totalLength = manifestBytes.size.toLong()
            )
        }

        val plan = parseHlsPlaylistTargets(finalPlaylistUrl, textSample)
        var initSegToPreload = plan.initSegmentUrl
        var mediaSegToPreload = plan.firstMediaSegmentUrl

        if (plan.isMasterPlaylist && !plan.variantPlaylistUrl.isNullOrBlank()) {
            if (genId != generationCounter.get()) return 0 to PreloadState.CANCELLED
            val variantUrl = plan.variantPlaylistUrl
            val variantFetch = fetchBoundedBytes(
                url = variantUrl,
                maxBytes = MAX_MANIFEST_BYTES,
                rangeHeader = null
            )
            if (variantFetch.failureState != null) {
                return 0 to variantFetch.failureState
            }
            val varBytes = variantFetch.data
            val varText = String(varBytes, Charsets.UTF_8)
            if (!varText.contains("#EXTM3U", ignoreCase = true)) {
                return 0 to PreloadState.INVALID_CONTENT
            }
            bytesLoaded += varBytes.size
            val resolvedVarUrl = variantFetch.finalUrl
            putRamCacheIfCurrentGen(
                genId = genId,
                url = variantUrl,
                ownerUrl = streamUrl,
                data = varBytes,
                contentType = variantFetch.contentType,
                isComplete = true,
                totalLength = varBytes.size.toLong()
            )
            if (resolvedVarUrl != variantUrl) {
                putRamCacheIfCurrentGen(
                    genId = genId,
                    url = resolvedVarUrl,
                    ownerUrl = streamUrl,
                    data = varBytes,
                    contentType = variantFetch.contentType,
                    isComplete = true,
                    totalLength = varBytes.size.toLong()
                )
            }
            val mediaPlan = parseHlsPlaylistTargets(resolvedVarUrl, varText)
            initSegToPreload = mediaPlan.initSegmentUrl
            mediaSegToPreload = mediaPlan.firstMediaSegmentUrl
        }

        val segLimit = activePerformanceMode.maxPreloadSegmentBytes
        if (segLimit > 0 && !slowNetworkDegraded && hasSafeHeapForPrefetch() && genId == generationCounter.get()) {
            val targetSegUrl = initSegToPreload ?: mediaSegToPreload
            if (!targetSegUrl.isNullOrBlank()) {
                val segBytes = preloadInitialSegmentToRam(
                    segmentUrl = targetSegUrl,
                    ownerStreamUrl = streamUrl,
                    genId = genId,
                    maxBytes = segLimit
                )
                if (segBytes > 0) {
                    bytesLoaded += segBytes
                }
            }
        }
        return bytesLoaded to null
    }

    private fun preloadInitialSegmentToRam(
        segmentUrl: String,
        ownerStreamUrl: String,
        genId: Long,
        maxBytes: Int = MAX_INITIAL_SEGMENT_BYTES
    ): Int {
        if (genId != generationCounter.get() || maxBytes <= 0) return 0
        val cappedBytes = maxBytes.coerceIn(16 * 1024, MAX_INITIAL_SEGMENT_BYTES)
        val segFetch = fetchBoundedBytes(
            url = segmentUrl,
            maxBytes = cappedBytes,
            rangeHeader = "bytes=0-${cappedBytes - 1}"
        )
        if (segFetch.failureState != null || segFetch.data.isEmpty()) return 0
        if (!isValidMediaSegmentBytes(segFetch.data, segFetch.contentType)) {
            return 0
        }
        if (segFetch.isComplete || segFetch.statusCode == 206) {
            putRamCacheIfCurrentGen(
                genId = genId,
                url = segmentUrl,
                ownerUrl = ownerStreamUrl,
                data = segFetch.data,
                contentType = segFetch.contentType,
                isComplete = segFetch.isComplete,
                totalLength = segFetch.totalResourceLength
            )
            if (segFetch.finalUrl != segmentUrl) {
                putRamCacheIfCurrentGen(
                    genId = genId,
                    url = segFetch.finalUrl,
                    ownerUrl = ownerStreamUrl,
                    data = segFetch.data,
                    contentType = segFetch.contentType,
                    isComplete = segFetch.isComplete,
                    totalLength = segFetch.totalResourceLength
                )
            }
            return segFetch.data.size
        }
        return 0
    }

    private fun putRamCacheIfCurrentGen(
        genId: Long,
        url: String,
        ownerUrl: String,
        data: ByteArray,
        contentType: String?,
        isComplete: Boolean,
        totalLength: Long
    ) {
        synchronized(stateLock) {
            if (genId != generationCounter.get()) return
            val resource = CachedPreloadResource(
                url = url,
                ownerStreamUrl = ownerUrl,
                data = data,
                contentType = contentType,
                timestampMs = System.currentTimeMillis(),
                isComplete = isComplete,
                totalResourceLength = totalLength
            )
            synchronized(ramPreloadCache) {
                ramPreloadCache.put(url, resource)
            }
        }
    }

    private fun parseTotalLengthFromContentRange(contentRange: String?): Long {
        if (contentRange.isNullOrBlank()) return C.LENGTH_UNSET.toLong()
        val slashIdx = contentRange.lastIndexOf('/')
        if (slashIdx < 0 || slashIdx >= contentRange.lastIndex) return C.LENGTH_UNSET.toLong()
        val totalStr = contentRange.substring(slashIdx + 1).trim()
        return totalStr.toLongOrNull() ?: C.LENGTH_UNSET.toLong()
    }

    private fun fetchBoundedBytes(
        url: String,
        maxBytes: Int,
        rangeHeader: String?
    ): FetchResult {
        val reqBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
            .header("Accept", "*/*")
            .get()
        if (!rangeHeader.isNullOrBlank()) {
            reqBuilder.header("Range", rangeHeader)
        }
        val call = NetworkClient.streamClient.newCall(reqBuilder.build())
        call.timeout().timeout(PRELOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        activeNetworkCall = call

        call.execute().use { res ->
            val code = res.code
            val statusFailure = classifyHttpStatus(code)
            val finalUrl = res.request.url.toString()
            val contentType = res.header("Content-Type")
            if (statusFailure != null) {
                return FetchResult(finalUrl, code, ByteArray(0), contentType, false, C.LENGTH_UNSET.toLong(), statusFailure)
            }
            val body = res.body
                ?: return FetchResult(finalUrl, code, ByteArray(0), contentType, false, C.LENGTH_UNSET.toLong(), PreloadState.INVALID_CONTENT)

            val contentRangeTotal = parseTotalLengthFromContentRange(res.header("Content-Range"))
            val declaredContentLength = body.contentLength()

            body.byteStream().use { input ->
                val out = ByteArrayOutputStream(maxBytes.coerceAtMost(16384))
                val buf = ByteArray(4096)
                var total = 0
                var reachedEof = false
                while (total < maxBytes) {
                    val toRead = (maxBytes - total).coerceAtMost(buf.size)
                    val r = input.read(buf, 0, toRead)
                    if (r < 0) {
                        reachedEof = true
                        break
                    }
                    if (r == 0) break
                    out.write(buf, 0, r)
                    total += r
                }
                if (!reachedEof) {
                    val nextByte = input.read()
                    if (nextByte < 0) reachedEof = true
                }
                val bytes = out.toByteArray()
                val isCompleteResource = when {
                    code == 200 && reachedEof -> true
                    code == 206 && contentRangeTotal > 0L && bytes.size.toLong() >= contentRangeTotal -> true
                    code == 200 && declaredContentLength in 1..bytes.size.toLong() -> true
                    else -> false
                }
                val totalLen = when {
                    contentRangeTotal > 0L -> contentRangeTotal
                    isCompleteResource -> bytes.size.toLong()
                    declaredContentLength > 0L && code == 200 -> declaredContentLength
                    else -> C.LENGTH_UNSET.toLong()
                }
                return FetchResult(finalUrl, code, bytes, contentType, isCompleteResource, totalLen, null)
            }
        }
    }

    private fun warmLiveSocketBounded(
        streamUrl: String,
        genId: Long,
        maxBytes: Int = 512
    ): Pair<Int, PreloadState?> {
        if (genId != generationCounter.get()) return 0 to PreloadState.CANCELLED
        val now = System.currentTimeMillis()
        val lastWarmed = synchronized(warmedSocketTimestamps) { warmedSocketTimestamps.get(streamUrl) }
        if (lastWarmed != null && (now - lastWarmed) < SOCKET_WARM_TTL_MS) {
            return maxBytes to null
        }
        val req = Request.Builder()
            .url(streamUrl)
            .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
            .header("Range", "bytes=0-${(maxBytes - 1).coerceAtLeast(127)}")
            .get()
            .build()
        val call = NetworkClient.streamClient.newCall(req)
        call.timeout().timeout(PRELOAD_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        activeNetworkCall = call
        call.execute().use { res ->
            val fail = classifyHttpStatus(res.code)
            if (fail != null) return 0 to fail
            val stream = res.body?.byteStream() ?: return 0 to PreloadState.INVALID_CONTENT
            stream.use { s ->
                val buf = ByteArray(maxBytes.coerceIn(128, 4096))
                val read = s.read(buf)
                return if (read > 0) read to null else (0 to PreloadState.INVALID_CONTENT)
            }
        }
    }

    fun buildLiveMediaItem(targetUrl: String): MediaItem {
        val cleanUrl = NetworkClient.extractCleanUrlAndRegisterHeaders(targetUrl)
        val pathLower = cleanUrl.substringBefore('?').lowercase(Locale.ROOT)
        val isVodFile = pathLower.endsWith(".mp4") ||
            pathLower.endsWith(".mkv") ||
            pathLower.endsWith(".avi") ||
            cleanUrl.contains("/movie/", ignoreCase = true) ||
            cleanUrl.contains("/series/", ignoreCase = true)
        val builder = MediaItem.Builder().setUri(cleanUrl)
        if (!isVodFile) {
            builder.setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setMaxPlaybackSpeed(1.02f)
                    .setMinPlaybackSpeed(0.98f)
                    .build()
            )
        }
        return builder.build()
    }

    fun consumePreparedMediaSource(targetUrl: String): MediaSource? {
        val cleanUrl = NetworkClient.extractCleanUrlAndRegisterHeaders(targetUrl)
        synchronized(stateLock) {
            val entry = preparedEntry
            if (entry == null) {
                preloadMissCount.incrementAndGet()
                return null
            }
            val age = System.currentTimeMillis() - entry.createdAtMs
            if (entry.streamUrl == cleanUrl &&
                entry.mediaSource != null &&
                entry.preloadedBytes > 0 &&
                age in 0..PREPARED_SOURCE_TTL_MS
            ) {
                preparedEntry = null
                currentState = PreloadState.HANDED_OFF
                preloadHitCount.incrementAndGet()
                return entry.mediaSource
            }
            if (age > PREPARED_SOURCE_TTL_MS) {
                preparedEntry = null
            }
            preloadMissCount.incrementAndGet()
            return null
        }
    }

    fun createPreloadAwareDataSourceFactory(upstreamFactory: OkHttpDataSource.Factory): DataSource.Factory {
        return DataSource.Factory {
            PreloadAwareDataSource(upstreamFactory.createDataSource())
        }
    }

    private class PreloadAwareDataSource(
        private val upstream: DataSource
    ) : BaseDataSource(/* isNetwork = */ true) {

        private var originalDataSpec: DataSpec? = null
        private var ramBytes: ByteArray? = null
        private var ramReadPosition: Int = 0
        private var ramBytesRemaining: Int = 0
        private var ramIsComplete: Boolean = true
        private var activeUri: Uri? = null
        private var openedUpstream: Boolean = false

        override fun open(dataSpec: DataSpec): Long {
            val urlStr = dataSpec.uri.toString()
            val cached = if (dataSpec.position == 0L) {
                synchronized(ramPreloadCache) {
                    val entry = ramPreloadCache.remove(urlStr)
                    if (entry != null && (System.currentTimeMillis() - entry.timestampMs) <= MANIFEST_CACHE_TTL_MS) {
                        entry
                    } else {
                        null
                    }
                }
            } else {
                null
            }

            if (cached != null && cached.data.isNotEmpty()) {
                originalDataSpec = dataSpec
                activeUri = dataSpec.uri
                ramBytes = cached.data
                ramReadPosition = 0
                ramIsComplete = cached.isComplete
                ramBytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
                    dataSpec.length.toInt().coerceAtMost(cached.data.size)
                } else {
                    cached.data.size
                }
                openedUpstream = false
                transferInitializing(dataSpec)
                transferStarted(dataSpec)
                return when {
                    dataSpec.length != C.LENGTH_UNSET.toLong() -> dataSpec.length
                    cached.isComplete -> cached.data.size.toLong()
                    cached.totalResourceLength > 0L -> cached.totalResourceLength
                    else -> C.LENGTH_UNSET.toLong()
                }
            }

            openedUpstream = true
            activeUri = dataSpec.uri
            return upstream.open(dataSpec)
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            if (length == 0) return 0
            val localBytes = ramBytes
            if (localBytes != null) {
                if (ramBytesRemaining > 0) {
                    val toCopy = length.coerceAtMost(ramBytesRemaining)
                    System.arraycopy(localBytes, ramReadPosition, buffer, offset, toCopy)
                    ramReadPosition += toCopy
                    ramBytesRemaining -= toCopy
                    bytesTransferred(toCopy)
                    return toCopy
                }
                val spec = originalDataSpec
                val explicitRequestSatisfied = spec != null &&
                    spec.length != C.LENGTH_UNSET.toLong() &&
                    ramReadPosition.toLong() >= spec.length
                if (ramIsComplete || explicitRequestSatisfied || spec == null) {
                    ramBytes = null
                    return C.RESULT_END_OF_INPUT
                }
                val prefixSize = localBytes.size.toLong()
                ramBytes = null
                val remainingLength = if (spec.length != C.LENGTH_UNSET.toLong()) {
                    (spec.length - prefixSize).coerceAtLeast(1L)
                } else {
                    C.LENGTH_UNSET.toLong()
                }
                val continuationSpec = spec.subrange(prefixSize, remainingLength)
                openedUpstream = true
                upstream.open(continuationSpec)
                return upstream.read(buffer, offset, length)
            }
            return upstream.read(buffer, offset, length)
        }

        override fun getUri(): Uri? {
            return if (ramBytes != null) activeUri else upstream.uri
        }

        @Throws(IOException::class)
        override fun close() {
            val hadRam = ramBytes != null
            ramBytes = null
            ramReadPosition = 0
            ramBytesRemaining = 0
            originalDataSpec = null
            activeUri = null
            if (openedUpstream) {
                openedUpstream = false
                upstream.close()
            } else if (hadRam) {
                transferEnded()
            }
        }
    }

    private fun transitionStateIfCurrent(genId: Long, newState: PreloadState) {
        synchronized(stateLock) {
            if (genId == generationCounter.get()) {
                currentState = newState
            }
        }
    }

    private fun cancelActiveNetworkCall() {
        runCatching { activeNetworkCall?.cancel() }
        activeNetworkCall = null
    }

    private fun evictEntriesExceptOwner(keepOwnerUrl: String) {
        val now = System.currentTimeMillis()
        synchronized(stateLock) {
            val prep = preparedEntry
            if (prep != null && (prep.streamUrl != keepOwnerUrl || (now - prep.createdAtMs) > PREPARED_SOURCE_TTL_MS)) {
                preparedEntry = null
            }
        }
        synchronized(ramPreloadCache) {
            val snapshot = ramPreloadCache.snapshot()
            for ((k, v) in snapshot) {
                if (v.ownerStreamUrl != keepOwnerUrl || (now - v.timestampMs) > MANIFEST_CACHE_TTL_MS) {
                    ramPreloadCache.remove(k)
                }
            }
        }
    }

    fun cancelAllPrefetches() {
        synchronized(stateLock) {
            generationCounter.incrementAndGet()
            cancelActiveNetworkCall()
            if (currentState == PreloadState.PRELOADING) {
                currentState = PreloadState.CANCELLED
            }
        }
        adjacentJob?.cancel()
        focusJob?.cancel()
    }

    fun trimIdleCacheOnLowMemory() {
        cancelAllPrefetches()
        synchronized(stateLock) {
            preparedEntry = null
            currentState = PreloadState.SKIPPED_LOW_MEM
        }
        synchronized(ramPreloadCache) {
            ramPreloadCache.evictAll()
        }
        synchronized(warmedSocketTimestamps) {
            warmedSocketTimestamps.evictAll()
        }
    }

    fun cacheUsedBytes(): Long {
        val ramManifestAndSegBytes = synchronized(ramPreloadCache) { ramPreloadCache.size().toLong() }
        val socketMetaBytes = synchronized(warmedSocketTimestamps) { warmedSocketTimestamps.size() * 256L }
        return ramManifestAndSegBytes + socketMetaBytes
    }

    fun currentPreloadState(): PreloadState = currentState

    fun currentGenerationId(): Long = generationCounter.get()

    fun preloadStatusSummary(): String {
        val hits = preloadHitCount.get()
        val misses = preloadMissCount.get()
        val ready = preloadReadyCount.get()
        val fails = preloadFailCount.get()
        val hitRate = prefetchHitRatePercent()
        val kb = cacheUsedBytes() / 1024
        return "${currentState.name} • HitRate:${hitRate}% (H:$hits/M:$misses/R:$ready/F:$fails) • ${kb}KB"
    }
}
